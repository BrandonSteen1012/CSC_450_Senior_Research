-- Simple query
UPDATE Largedataset_Customers
SET country = 'Canada'
WHERE customer_id = 'CUST_84964';

-- Medium Query
UPDATE Largedataset_Transactions
SET amount = amount * 0.85
WHERE amount > 1000.00 AND currency = 'USD';

-- Complex Query
UPDATE Largedataset_Merchants
SET high_risk = 'TRUE'
WHERE merchant_id IN (
    SELECT merchant_id 
    FROM LargeDataset_Transactions 
    WHERE amount > 5000.00 
    GROUP BY merchant_id 
    HAVING COUNT(transaction_id) > 3
);
