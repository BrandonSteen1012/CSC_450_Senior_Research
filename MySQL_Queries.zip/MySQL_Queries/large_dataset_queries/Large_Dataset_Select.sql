SELECT transaction_id, customer_id, amount, timestamp
FROM largedataset_transactions
LIMIT 100000;

SELECT t.transaction_id, c.customer_id, c.country, t.amount, t.timestamp
FROM MediumDataset_Transactions t
JOIN MediumDataset_Customers c ON t.customer_id = c.customer_num_id
WHERE c.country = 'USA' AND t.amount > 100.00
ORDER BY t.timestamp DESC
LIMIT 1000000;

SELECT m.merchant_name, m.merchant_category, SUM(t.amount) AS total_amount, COUNT(t.transaction_id) AS transaction_count
FROM largedataset_transactions t
JOIN largedataset_customers c ON t.customer_id = c.customer_num_id
JOIN largedataset_merchants m ON t.merchant_id = m.merchant_num_id
WHERE m.high_risk = 'Yes' AND c.city_size = 'Large'
GROUP BY m.merchant_name, m.merchant_category
HAVING total_amount > 10000.00
ORDER BY total_amount DESC
LIMIT 1000000;