SELECT transaction_id, customer_id, amount FROM smalldataset LIMIT 5000;

SELECT customer_id, count(transaction_id) as transactions, sum(amount) as total_spent 
FROM smalldataset
WHERE amount > 500.00
group by customer_idmediumdataset_customers
ORDER BY total_spent DESC
LIMIT 5000;

SELECT customer_id, 
       SUM(amount) AS total_spent, 
       COUNT(transaction_id) AS transaction_count, 
       RANK() OVER (ORDER BY SUM(amount) DESC) AS rank_by_spent
FROM smalldataset
WHERE amount > 10.00
GROUP BY customer_id
HAVING total_spent > 1000.00
LIMIT 5000;

