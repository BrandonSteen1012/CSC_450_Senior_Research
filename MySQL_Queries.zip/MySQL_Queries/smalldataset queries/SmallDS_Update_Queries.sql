UPDATE small_dataset_transactions
SET amount = 500.00
WHERE transaction_id = 'TX_0015e89d';

UPDATE small_dataset_transactions
SET amount = amount * 1.2
WHERE amount > 500.00;

UPDATE small_dataset_transactions
SET amount = amount * 1.3
WHERE amount > 100.00 AND card_present = "TRUE";


