-- Merchants Table
CREATE TABLE MediumDataset_Merchants (
    merchant_id INT PRIMARY KEY,
    merchant_category VARCHAR(50),
    merchant_type VARCHAR(50),
    merchant_name VARCHAR(100)
);

-- Customers Table
CREATE TABLE MediumDataset_Customers (
    customer_id INT PRIMARY KEY,
    card_number VARCHAR(16) NOT NULL,
    card_type VARCHAR(50),
    card_present BOOLEAN,
    country VARCHAR(50)
);

-- Transactions Table
CREATE TABLE MediumDataset_Transactions (
    transaction_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    timestamp DATETIME NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) NOT NULL,
    merchant_id INT NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES MediumDataset_Customers(customer_id),
    FOREIGN KEY (merchant_id) REFERENCES MediumDataset_Merchants(merchant_id)
);

