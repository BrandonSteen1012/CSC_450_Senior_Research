insert into largedataset_customers(customer_id, country, city_size, city, card_type, card_number, distance_from_home)
(select customer_id, country, city_size, city, card_type, card_number, distance_from_home from temp_import limit 500000);

insert into largedataset_merchants(merchant_type, merchant_name, merchant_category, high_risk)
(select merchant_type, merchant_name, merchant_category, high_risk_merchant from temp_import limit 500000);

insert into largedataset_devices(device_fingerprint, device_type, ip_address)
(select device_fingerprint, device, ip_address from temp_import limit 500000);

insert into largedataset_transactions(customer_id, merchant_id, device_id, `timestamp`, amount, currency, is_fraud, `channel`)
select
(select customer_num_id from largedataset_customers where largedataset_customers.customer_num_id = temp_import.id),
(select merchant_num_id from largedataset_merchants where largedataset_merchants.merchant_num_id = temp_import.id),
(select device_id from largedataset_devices where largedataset_devices.device_id = temp_import.id),
`timestamp`, amount, currency, is_fraud, `channel` from temp_import limit 50000;

SET SQL_SAFE_UPDATES = 0;
delete from largedataset_transactions limit 100000;
ALTER TABLE largedataset_devices AUTO_INCREMENT=1;


select count(*) from largedataset_transactions