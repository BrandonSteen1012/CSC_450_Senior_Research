insert into mediumdataset_customers(customer_id, card_number, card_type, card_present, country)
select customer_id, card_number, card_type, card_present, country
from temp_import
limit 100000;

insert into mediumdataset_merchants(merchant_category, merchant_type, merchant_name)
select merchant_category, merchant_type, merchant_name from temp_import
limit 100000;

insert into mediumdataset_transactions(customer_id, merchant_id, card_number, amount, currency, `timestamp`)(select 
    (SELECT customer_num_id FROM mediumdataset_customers WHERE customer_num_id = temp_import.id),
    (SELECT merchant_num_id FROM mediumdataset_merchants WHERE merchant_num_id = temp_import.id),
    temp_import.card_number,
    temp_import.amount,
    temp_import.currency,
    temp_import.timestamp
FROM 
    temp_import limit 100000);

