CREATE TABLE `mediumdataset_customers` (
  `customer_num_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` varchar(255) NOT NULL,
  `card_number` varchar(255) NOT NULL,
  `card_type` varchar(255) DEFAULT NULL,
  `card_present` varchar(10) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`customer_num_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `mediumdataset_merchants` (
  `merchant_num_id` int NOT NULL AUTO_INCREMENT,
  `merchant_id` varchar(255) NOT NULL,
  `merchant_category` varchar(255) DEFAULT NULL,
  `merchant_type` varchar(255) DEFAULT NULL,
  `merchant_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`merchant_num_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE mediumdataset_transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY, -- Surrogate primary key
    customer_id INT,                              -- Foreign key referencing customers
    merchant_id INT,                              -- Foreign key referencing merchants
    card_number VARCHAR(255),
    amount DECIMAL(10, 2),
    currency VARCHAR(10),
    timestamp DATETIME,
    FOREIGN KEY (customer_id) REFERENCES mediumdataset_customers(customer_num_id),
    FOREIGN KEY (merchant_id) REFERENCES mediumdataset_merchants(merchant_num_id)
);