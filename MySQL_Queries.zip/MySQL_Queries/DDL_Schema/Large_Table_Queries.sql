
-- Merchants Table
CREATE TABLE LargeDataset_Merchants (
    merchant_id INT PRIMARY KEY,
    merchant_category VARCHAR(50),
    merchant_type VARCHAR(50),
    merchant_name VARCHAR(100),
    high_risk BOOLEAN
);

-- Customers Table
CREATE TABLE LargeDataset_Customers (
    customer_id INT PRIMARY KEY,
    card_number VARCHAR(16) NOT NULL,
    card_type VARCHAR(50),
    country VARCHAR(50),
    city VARCHAR(50),
    city_size VARCHAR(20),
    distance_from_home BOOLEAN
);

-- Devices Table
CREATE TABLE LargeDataset_Devices (
    device_id INT PRIMARY KEY,
    device_type VARCHAR(50),
    device_fingerprint VARCHAR(255),
    ip_address VARCHAR(50)
);

-- Transactions Table
CREATE TABLE LargeDataset_Transactions (
    transaction_id INT PRIMARY KEY,
    customer_id INT NOT NULL,
    timestamp DATETIME NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3),
    merchant_id INT NOT NULL,
    channel VARCHAR(50),
    device_id INT,
    is_fraud BOOLEAN,
    FOREIGN KEY (customer_id) REFERENCES LargeDataset_Customers(customer_id),
    FOREIGN KEY (merchant_id) REFERENCES LargeDataset_Merchants(merchant_id),
    FOREIGN KEY (device_id) REFERENCES LargeDataset_Devices(device_id)
);


-- Velocity Table
CREATE TABLE LargeDataset_Velocity (
    transaction_id INT PRIMARY KEY,
    num_transactions INT,
    total_amount DECIMAL(10, 2),
    unique_merchants INT,
    unique_countries INT,
    max_single_amount DECIMAL(10, 2),
    FOREIGN KEY (transaction_id) REFERENCES LargeDataset_Transactions(transaction_id)
);
