-- Simple Query
UPDATE mediumdataset_customers
SET card_type = 'Gold'
WHERE customer_id = "CUST_72886";

-- Medium Query
UPDATE Mediumdataset_Transactions
SET amount = amount * 1.15
WHERE amount > 200.00 AND currency = 'USD';

-- Complex Query
UPDATE Mediumdataset_Merchants
SET merchant_type = 'Preferred'
WHERE merchant_category = 'Electronics' AND merchant_name LIKE 'Best%';
